package it.sonlesson25.lesson25_0;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lesson250ApplicationTests {

	@Test
	void contextLoads() {
	}

}
