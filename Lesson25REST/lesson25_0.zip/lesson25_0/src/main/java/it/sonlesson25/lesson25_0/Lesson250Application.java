package it.sonlesson25.lesson25_0;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lesson250Application {

	public static void main(String[] args) {
		SpringApplication.run(Lesson250Application.class, args);
	}

}
